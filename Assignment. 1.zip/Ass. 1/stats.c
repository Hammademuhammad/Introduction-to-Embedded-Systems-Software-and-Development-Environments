/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief The implementation file of the c1m1 assignment
 *
 * This file includes all the required functions implementations in the c1m1 assignment
 *
 * @author Hammad e Muhammad
 * @date 1/6/2024
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

#include <stdio.h>

void print_statistics(unsigned char minimum, unsigned char maximum, float mean, unsigned char median) {
  printf("The minimum is %u\n", minimum);
  printf("The maximum is %u\n", maximum);
  printf("The mean is %.2f\n", mean);
  printf("The median is %u\n", median);
}

void print_array(unsigned char *array, unsigned int counter) {
  for (int i = 0; i < counter; i++) {
    printf("%u,", *(array + i));
  }
  printf("\n");
}

unsigned char find_median(unsigned char *array, unsigned int counter) {
  unsigned char median = *(array + (counter / 2) - 1);
  return median;
}

float find_mean(unsigned char *array, unsigned int counter) {
  unsigned int accumulator = 0;
  float mean = 0.0f; // Cast to float for accurate calculation
  for (int i = 0; i < counter; i++) {
    accumulator += array[i];
  }
  mean = (float)accumulator / counter;
  return mean;
}

unsigned char find_maximum(unsigned char *array, unsigned int counter) {
  unsigned char maximum = *array;
  for (int i = 1; i < counter; i++) {
    if (*(array + i) > maximum) {
      maximum = *(array + i);
    }
  }
  return maximum;
}

unsigned char find_minimum(unsigned char *array, unsigned int counter) {
  unsigned char minimum = *array;
  for (int i = 1; i < counter; i++) {
    if (*(array + i) < minimum) {
      minimum = *(array + i);
    }
  }
  return minimum;
}

void sort_array(unsigned char *array, unsigned int counter) {
  char flag = 0;
  unsigned char temp;
  do {
    flag = 0;
    for (int index = 0; index < counter - 1; index++) {
      if (array[index] > array[index + 1]) {
        temp = array[index];
        array[index] = array[index + 1];
        array[index + 1] = temp;
        flag = 1;
      }
    }
  } while (flag == 1);
}

int main() {
  unsigned char test[] = {34, 201, 190, 154, 8, 194, 2, 6,
                         114, 88, 45, 76, 123, 87, 25, 23,
                         200, 122, 150, 90, 92, 87, 177, 244,
                         201, 6, 12, 60, 8, 2, 5, 67,
                         7, 87, 250, 230, 99, 3, 100, 90};

  unsigned char minimum = find_minimum(test, sizeof(test) / sizeof(test[0]));
  unsigned char maximum = find_maximum(test, sizeof(test) / sizeof(test[0]));
  float mean = find
}

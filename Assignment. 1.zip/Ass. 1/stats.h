/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Definitions and macros required for the c1m1 assignment
 *
 *
 * @author Hammad e Muhammad
 * @date 1/6/2024
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief Prints the statistics of a given array
 *
 * This function takes the resulting statistics done on an array
 * which are: minimum, maximum, mean and median, and print those
 * values on the screen
 * 
 * @param minimum The minimum number of the given array
 * @param maximum The maximum number of the given array
 * @param mean The mean of the given array
 * @param median The median of the given array
 *
 * @return void
 */
#include <stdio.h>

/**
 * @brief Prints the contents of a given array
 *
 * This function takes the given array and prints it to the
 * screen.
 *
 * @param array The first element of the array to be printed on the screen
 * @param counter The size of the array
 *
 * @return void
 */
void print_array(unsigned char *array, unsigned int counter) {
  for (int i = 0; i < counter; i++) {
    printf("%u ", array[i]);
  }
  printf("\n");
}

/**
 * @brief Finds the median of the given array
 *
 * This function takes the given array and finds its median
 * without sorting. It assumes the array size is odd.
 *
 * @param array The first element of the array to be processed
 * @param counter The size of the array (assumed to be odd)
 *
 * @return median The median value of the given array.
 */
unsigned char find_median(unsigned char *array, unsigned int counter) {
  int middle_index = counter / 2;
  return array[middle_index];
}

/**
 * @brief Finds the mean of the given array
 *
 * This function takes the given array and finds its mean (average) value.
 *
 * @param array The first element of the array to be processed
 * @param counter The size of the array
 *
 * @return mean The mean value of the given array.
 */
float find_mean(unsigned char *array, unsigned int counter) {
  float sum = 0;
  for (int i = 0; i < counter; i++) {
    sum += array[i];
  }
  return sum / counter;
}

/**
 * @brief Finds the maximum of the given array
 *
 * This function takes the given array and finds its maximum value.
 *
 * @param array The first element of the array to be processed
 * @param counter The size of the array
 *
 * @return maximum The maximum value of the given array.
 */
unsigned char find_maximum(unsigned char *array, unsigned int counter) {
  unsigned char max_value = array[0];
  for (int i = 1; i < counter; i++) {
    if (array[i] > max_value) {
      max_value = array[i];
    }
  }
  return max_value;
}

/**
 * @brief Finds the minimum of the given array
 *
 * This function takes the given array and finds its minimum value.
 *
 * @param array The first element of the array to be processed
 * @param counter The size of the array
 *
 * @return minimum The minimum value of the given array.
 */
unsigned char find_minimum(unsigned char *array, unsigned int counter) {
  unsigned char min_value = array[0];
  for (int i = 1; i < counter; i++) {
    if (array[i] < min_value) {
      min_value = array[i];
    }
  }
  return min_value;
}

/**
 * @brief Prints the statistics of the given data
 *
 * This function takes the pre-calculated minimum, maximum, mean, and median values
 * and prints them in a user-friendly format.
 *
 * @param minimum The minimum value in the data set
 * @param maximum The maximum value in the data set
 * @param mean The mean (average) value in the data set
 * @param median The median value in the data set
 *
 * @return void
 */
void print_statistics(unsigned char minimum, unsigned char maximum, float mean, unsigned char median) {
  printf("Statistics:\n");
  printf("  Minimum: %u\n", minimum);
  printf("  Maximum: %u\n", maximum);
  printf("  Mean: %.2f\n", mean);
  printf("  Median: %u\n", median);
}

// Example usage (assuming you have an array of unsigned char called 'data' with size 'data_size')
int main() {
  unsigned char minimum = find_minimum(data, data_size);
  unsigned char maximum = find_maximum(data, data_size);
  float mean = find_mean(data, data_size);
  unsigned char median =
#endif /* __STATS_H__ */
